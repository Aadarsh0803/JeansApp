import { useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";
import './GetProductById.css';
import JeansMen from 'D:/Work/AReact/react-axios-api/src/images/JeansMen.webp'
import { useNavigate } from "react-router-dom";


const GetProductById = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const productFromState = location.state?.product;
    const productId = sessionStorage.getItem("productId");

    const [product, setProduct] = useState({
        productId: "",
        productName: "",
        productDescription: "",
        gender: "",
        cloth: "",
        age: "",
        price: 0,
        discount: 0,
        size: 0,
        quantity: 0,
        color: "",
        brand: ""
    });

    useEffect(() => {
        if (productFromState) {
            setProduct(productFromState);
        } else if (productId) {
            fetchProductById(productId);
        }
    }, [productFromState, productId]);

    const fetchProductById = async (id) => {
        try {
            const response = await axios.get(`/api/products/${id}`);
            setProduct(response.data);
        } catch (error) {
            console.error("Error fetching product data", error);
        }
    };

    const [selectedProduct, setSelectedProduct] = useState([]); 

    const handleAddToWish = (product) => {
        setSelectedProduct(product);
        navigate("/AddWish", { state: { product } }); 
    };

    const handleAddToCart = (product) => {
        setSelectedProduct(product);
        navigate("/AddCart", { state: { product } }); 
    };
    const [orderPlaced, setOrderPlaced] = useState(false); 

    const handleAddToOrder = (product) => {
        if(!selectedProduct.some(p=>p.productId === product.productId)){
            setSelectedProduct([...selectedProduct,product])
            console.log(product);
            setOrderPlaced(true);
            alert("Product added to order")
        }
    };


    const handleGoToOrders = () => {
        navigate("/AddOrder", { state: { orderItems:selectedProduct} });  
    };

    return (
        <div className="container mt-4">
            <div className="product-details card p-3">
                <div className="row">
                    <div className="col-md-4 text-center">
                        <div className="product-image">
                            <img src={JeansMen} alt="Product" className="img-fluid" />
                        </div>
                    </div>

                    <div className="col-md-8">
                        <h2 className="product-title mb-3">
                            {product.productName} <span className="product-id">(ID: {product.productId})</span>
                        </h2>
                        <h4 className="product-price">
                            Price: ₹{product.price}/- 
                            <span className="product-discount"> - {product.discount}% Off</span>
                        </h4>
                        <p className="product-description mt-3">
                            {product.productDescription}
                        </p>

                        <div className="product-details mt-4">
                            <p><strong>Gender:</strong> {product.gender}</p>
                            <p><strong>Cloth Type:</strong> {product.cloth}</p>
                            <p><strong>Age Group:</strong> {product.age}</p>
                            <p><strong>Size:</strong> {product.size}</p>
                            <p><strong>Available Quantity:</strong> {product.quantity}</p>
                            <p><strong>Color:</strong> {product.color}</p>
                            <p><strong>Brand:</strong> {product.brand}</p>
                        </div>
                        <br/>
                        <button className="btn btn-primary" onClick={()=> handleAddToCart(product)} >Add to Cart</button>
                        <button className="btn btn-warning" onClick={()=>handleAddToWish(product)}>Add to Wish</button>
                        {orderPlaced ? (
                            <button className="btn btn-primary" onClick={handleGoToOrders}>
                            Go to Orders
                            </button>
                        ) : (
                            <button className="btn btn-success" onClick={() => handleAddToOrder(product)}>
                            Place Order
                            </button>
                        )}                        
                        <br/><br/>
                        <button className="btn btn-secondary" onClick={()=>navigate("/GetAllProducts")}>Back</button>
                    </div>
                    
                </div>
            </div>
        </div>
    );
};

export default GetProductById;
