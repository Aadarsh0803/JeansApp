import React, { useState, useEffect } from "react";
import axios from "axios";

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [filters, setFilters] = useState({
    gender: "",
    cloth: "",
    age: "",
    size: "",
    color: "",
    brand: "",
  });
  const [error, setError] = useState("");

  const fetchProducts = async () => {
    try {
      const params = {};
      Object.keys(filters).forEach((key) => {
        if (filters[key]) {
          params[key] = filters[key];
        }
      });
      const response = await axios.get("http://localhost:5263/api/Product/GetByCategory?", {
        params: params,
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`, // Assuming token is stored in sessionStorage
        },
      });
      setProducts(response.data);
    } catch (error) {
      setError(error.response ? error.response.data : "Error fetching products");
    }
  };

  useEffect(() => {
    fetchProducts();
  }, [filters]); // Fetch products when filters change

  const handleFilterChange = (e) => {
    setFilters({
      ...filters,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div>
      <h2>Product List</h2>
      
      {/* Filters */}
      <div className="filters">
        <input
          type="text"
          name="gender"
          placeholder="Gender"
          value={filters.gender}
          onChange={handleFilterChange}
        />
        <input
          type="text"
          name="cloth"
          placeholder="Cloth"
          value={filters.cloth}
          onChange={handleFilterChange}
        />
        <input
          type="text"
          name="age"
          placeholder="Age"
          value={filters.age}
          onChange={handleFilterChange}
        />
        <input
          type="number"
          name="size"
          placeholder="Size"
          value={filters.size}
          onChange={handleFilterChange}
        />
        <input
          type="text"
          name="color"
          placeholder="Color"
          value={filters.color}
          onChange={handleFilterChange}
        />
        <input
          type="text"
          name="brand"
          placeholder="Brand"
          value={filters.brand}
          onChange={handleFilterChange}
        />
        <button onClick={fetchProducts}>Filter</button>
      </div>

      {/* Display Error */}
      {error && <p style={{ color: "red" }}>{error}</p>}

      {/* Products Table */}
      {products.length > 0 ? (
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Description</th>
              <th>Gender</th>
              <th>Cloth</th>
              <th>Age</th>
              <th>Size</th>
              <th>Color</th>
              <th>Brand</th>
              <th>Price</th>
              <th>Discount</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.productId}>
                <td>{product.productName}</td>
                <td>{product.productDescription}</td>
                <td>{product.gender}</td>
                <td>{product.cloth}</td>
                <td>{product.age}</td>
                <td>{product.size}</td>
                <td>{product.color}</td>
                <td>{product.brand}</td>
                <td>{product.price}</td>
                <td>{product.discount}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No products found</p>
      )}
    </div>
  );
};

export default ProductList;
