import { useState, useEffect } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';

const RemoveCart = () => {
  const [product, setProduct] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");
  const cartId = sessionStorage.getItem("CartId");

  useEffect(() => {
    const removeProductFromCart = () => {
      if (window.confirm("Are you sure you want to delete this product from the cart?")) {
        axios
          .delete(`http://localhost:5263/api/Cart/DeleteCart?cartId=${cartId}`, {
            headers: {
              Authorization: `Bearer ${sessionStorage.getItem('token')}`,
            },
          })
          .then((res) => {
            console.log(res.data);
            setProduct(null);
            alert("Cart item removed successfully.");
          })
          .catch((err) => {
            console.log(err);
            setErrorMessage("Error deleting");
          });
      }
    };

    // Call the function only once on mount
    removeProductFromCart();
  }, [cartId]); // Dependency array ensures the effect runs once when the component mounts

  return (
    <div>
      {errorMessage && <p>{errorMessage}</p>}
    </div>
  );
};

export default RemoveCart;
