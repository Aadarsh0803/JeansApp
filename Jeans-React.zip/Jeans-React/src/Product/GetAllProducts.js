import React, { useEffect, useState } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from "react-router-dom";
import JeansMen from 'D:/Work/AReact/react-axios-api/src/images/JeansMen.webp'
import jeansKids from 'D:/Work/AReact/react-axios-api/src/images/jeansKids.jpg'
import JeansWomen from 'D:/Work/AReact/react-axios-api/src/images/JeansWomen.jpg'
import JeansWomen2 from 'D:/Work/AReact/react-axios-api/src/images/JeansWomen2.webp'


const GetAllProducts = () => {

    const images = [JeansMen,JeansWomen,JeansWomen2,jeansKids];


    const [products, setProducts] = useState([]);
    const [selectedProduct, setSelectedProduct] = useState([]); 
    const navigate = useNavigate();
    // const ImageCarousel = ({ images }) => {
    //     const [currentIndex, setCurrentIndex] = useState(0);
    // }
    
    useEffect(() => {
        axios.get("http://localhost:5263/api/Product/GetAllProducts", {
            headers: {            
                Authorization: `Bearer ${sessionStorage.getItem('token')}`
            }
        })
        .then((response) => {
            setProducts(response.data);
        })
        .catch((error) => console.log(error));
    }, []);
  
    const handleAddToWish = (product) => {
        setSelectedProduct(product);
        navigate("/AddWish", { state: { product } }); 
    };

    const handleAddToCart = (product) => {
        setSelectedProduct(product);
        navigate("/AddCart", { state: { product } }); 
    };

    const handleAddToOrder = (product) => {
        if(!selectedProduct.some(p=>p.productId === product.productId)){
            setSelectedProduct([...selectedProduct,product])
            alert("Product added to order")
        }
    };

    const handleGoToOrders = () => {
        navigate("/AddOrder", { state: { orderItems:selectedProduct} });  
    };
    const handleViewProduct = (product) => {
        setSelectedProduct(product);
        sessionStorage.setItem("productId", product.productId);
        navigate(`/GetProductById`, { state: { product } });
    };
    

    return (
        <>
        <button className="btn btn-secondary" onClick={() => navigate("/WelcomePage")}>Back</button>

        <div className="container mt-5">
            <h2 className="mb-4">All Products</h2>
            <button className="btn btn-primary mb-3" onClick={() => navigate("/GetCart")}>View Cart</button>
            <button className="btn btn-info mb-3" onClick={handleGoToOrders}>Go to Orders</button>
            
            <table className="table table-bordered table-hover">
                <thead className="table-primary">
                    <tr>
                        <th>Image</th>
                        <th>Product ID</th>
                        <th>Product Name</th>
                        <th>Description</th>
                        <th>Gender</th>
                        <th>Cloth</th>
                        <th>Age</th>
                        <th>Price</th>
                        <th>Discount (%)</th>
                        <th>Size</th>
                        <th>Color</th>
                        <th>Brand</th>
                        <th>View Product</th>
                        <th>Add to Order</th>
                    </tr>
                </thead>
                <tbody>
                    
                    {products.map((product) => (
                        <tr key={product.productId}>
                            <td><img src={JeansMen} alt={`Jeans`} width={60} /></td>
                            <td>{product.productId}</td>
                            <td>{product.productName}</td>
                            <td>{product.productDescription}</td>
                            <td>{product.gender}</td>
                            <td>{product.cloth}</td>
                            <td>{product.age}</td>
                            <td>{product.price}</td>
                            <td>{product.discount}</td>
                            <td>{product.size}</td>
                            <td>{product.color}</td>
                            <td>{product.brand}</td>
                            <td>
                                <button className="btn btn-success" onClick={() => handleViewProduct(product)}>
                                    View Product
                                </button>
                            </td>
                       
                            <td>
                                <button className="btn btn-primary" onClick={() => handleAddToOrder(product)}>
                                   Add to Order
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
        </>
    );
};

export default GetAllProducts;
