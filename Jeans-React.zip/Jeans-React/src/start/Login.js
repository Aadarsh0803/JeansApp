import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
const Login = () => {
  const [name, setName] = useState("");  // State for username/email input
  const [pwd, setPwd] = useState("");    // State for password input
  const [err, setErr] = useState("");    // State for error messages
  const navigate = useNavigate();        // Navigation hook

  const checkType = (input) => {
    if (input.includes('@')) {
      return 'email';
    }
    return 'username';
  };

  const validate = (e) => {
    e.preventDefault();

    const type = checkType(name);
    let user;
    if (type === 'email') {
      user = { email: name, password: pwd, username: ''};
    } else {
      user = { username: name, password: pwd, email:'' };
    }
    axios
      .post("http://localhost:5263/api/Customer/Validate", user)
      .then((response) => {
        console.log(response);
        if (response.status === 204) {
          setErr("Invalid User Credentials");  
        } else {
          const userData = response.data;
          
          console.log(userData.token);
          sessionStorage.setItem("token", userData.token);  
          sessionStorage.setItem("email",userData.email);
          sessionStorage.setItem("id",userData.customerId);
          sessionStorage.setItem("userName",userData.userName);
          sessionStorage.setItem("role",userData.role);
          console.log(userData);
          if (userData.role === "Customer") {
            navigate("/WelcomePage");
          } else if (userData.role === "Admin") {
            navigate("/WelcomeAdmin");
          }
        }
      })
      .catch((error) => {
        console.error("There was an error validating the user!", error);
        setErr("An error occurred while trying to log in.");
      });
  };

  return (
    <>
      <form onSubmit={validate}>
        <table className="d-flex flex-column justify-content-center align-items-center vh-100"style={{backgroundColor:"silver"}}>
          <tbody>
            <tr>
              <td>Username/Email</td>
              <td>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}  // Update state on input change
                />
              </td>
            </tr>
            <tr>
              <td>Password</td>
              <td>
                <input
                  type="password"
                  value={pwd}
                  onChange={(e) => setPwd(e.target.value)}  // Update state on input change
                />
              </td>
            </tr>
            <tr>
              <td colSpan={2}>
                <button type="submit"  className="btn btn-primary">Login</button> 
                <button className="btn btn-secondary" onClick={()=>navigate("/")}>Back</button>
                
              </td>
            </tr>
            <tr>
              <td colSpan={2}>
                <span>{err}</span> 
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </>
  );
};

export default Login;
