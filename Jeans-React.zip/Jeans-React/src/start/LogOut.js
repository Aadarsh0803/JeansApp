import { useNavigate } from "react-router-dom";

const Logout = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    sessionStorage.clear(); 
    navigate("/login");      
  };
  const handleBack =()=>{
    const role = sessionStorage.getItem("role")
    if(role === 'Admin'){
      navigate("/WelcomeAdmin")
    }
    else{
      navigate("/WelcomePage")
    }
  }

  return (
    <div className="text-center mt-4" >
      <h1>Are you sure you want to logout?</h1><br></br>
      <button onClick={handleLogout} className="btn btn-primary" >Logout</button>
      
      <button onClick={handleBack}  className="btn btn-secondary">Back</button>
    </div>
  );
};

export default Logout;
