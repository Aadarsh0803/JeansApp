import React from "react";
import { useNavigate } from "react-router-dom";

const Start = () => {
  const navigate = useNavigate();

  return (
    <div className="d-flex flex-column justify-content-center align-items-center vh-100" style={{backgroundColor:"silver"}}>
      <h3>Welcome to Jeans App</h3>
      <p>Choose to start the application</p>
      <div className="mt-4">
        <div className="mb-3 text-center">
          <p>Already have an account?</p>
          <button className="btn btn-primary" onClick={() => navigate("/login")}>
            Login
          </button>
        </div>
        <div className="text-center">
          <p>New User?</p>
          <button className="btn btn-secondary" onClick={() => navigate("/register")}>
            Register
          </button>
        </div>
      </div>
    </div>
  );
};

export default Start;
