import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const generateItemId = () => {
    const randomId = Math.floor(Math.random() * 1000).toString().padStart(3, "0");
    return `U${randomId}`;
  };
const Register = () => {
  const [Customer, setCustomer] = useState({
    customerId: generateItemId(),
    userName: "",
    firstName: "",
    lastName: "",
    role: "Customer",
    email: "",
    password: "",
    phoneNumber: "",
    address: "",
    city: "",
    state: "",
    postalCode: "",
    country: ""
  });

  const navigate = useNavigate();

  const save = async (e) => {
    e.preventDefault();
    console.log(Customer);


    
    try {
      const res = await axios.post(
        "http://localhost:5263/api/Customer/Add",
        Customer,
        {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`,
          },
        }
      );
      console.log(res.data);
      navigate("/Login");
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <form onSubmit={save}>
      <h2>Jeans</h2>
      <p>
        Sign up to explore the latest styles and exclusive offers
        <br /> on jeans from your favorite brands!
      </p>

      <table className="table table-bordered">
        <tbody>
          
          <tr>
            <td>Username</td>
            <td>
              <input
                type="text"
                value={Customer.userName}
                onChange={(e) =>
                  setCustomer((prevObj) => ({
                    ...prevObj,
                    userName: e.target.value,
                  }))
                }
              />
            </td>
          </tr>
          <tr>
            <td>First Name</td>
            <td>
              <input
                type="text"
                value={Customer.firstName}
                onChange={(e) =>
                  setCustomer((prevObj) => ({
                    ...prevObj,
                    firstName: e.target.value,
                  }))
                }
              />
            </td>
          </tr>
          <tr>
            <td>Last Name</td>
            <td>
              <input
                type="text"
                value={Customer.lastName}
                onChange={(e) =>
                  setCustomer((prevObj) => ({
                    ...prevObj,
                    lastName: e.target.value,
                  }))
                }
              />
            </td>
          </tr>
          <tr>
            <td>Role</td>
            <td>
              <select
                value={Customer.role}
                onChange={(e) =>
                  setCustomer((prevObj) => ({
                    ...prevObj,
                    role: e.target.value,
                  }))
                }
              >
                <option value="Customer">Customer</option>
                <option value="Admin">Admin</option>
              </select>
            </td>
          </tr>
          <tr>
            <td>Email</td>
            <td>
              <input
                type="email"
                value={Customer.email}
                onChange={(e) =>
                  setCustomer((prevObj) => ({
                    ...prevObj,
                    email: e.target.value,
                  }))
                }
              />
            </td>
          </tr>
          <tr>
            <td>Password</td>
            <td>
              <input
                type="password"
                value={Customer.password}
                onChange={(e) =>
                  setCustomer((prevObj) => ({
                    ...prevObj,
                    password: e.target.value,
                  }))
                }
              />
            </td>
          </tr>
          <tr>
            <td>Phone Number</td>
            <td>
              <input
                type="text"
                value={Customer.phoneNumber}
                onChange={(e) =>
                  setCustomer((prevObj) => ({
                    ...prevObj,
                    phoneNumber: e.target.value,
                  }))
                }
              />
            </td>
          </tr>
          <tr>
            <td>Address</td>
            <td>
              <input
                type="text"
                value={Customer.address}
                onChange={(e) =>
                  setCustomer((prevObj) => ({
                    ...prevObj,
                    address: e.target.value,
                  }))
                }
              />
            </td>
          </tr>
          <tr>
            <td>City</td>
            <td>
              <input
                type="text"
                value={Customer.city}
                onChange={(e) =>
                  setCustomer((prevObj) => ({
                    ...prevObj,
                    city: e.target.value,
                  }))
                }
              />
            </td>
          </tr>
          <tr>
            <td>State</td>
            <td>
              <input
                type="text"
                value={Customer.state}
                onChange={(e) =>
                  setCustomer((prevObj) => ({
                    ...prevObj,
                    state: e.target.value,
                  }))
                }
              />
            </td>
          </tr>
          <tr>
            <td>Postal Code</td>
            <td>
              <input
                type="text"
                value={Customer.postalCode}
                onChange={(e) =>
                  setCustomer((prevObj) => ({
                    ...prevObj,
                    postalCode: e.target.value,
                  }))
                }
              />
            </td>
          </tr>
          <tr>
            <td>Country</td>
            <td>
              <input
                type="text"
                value={Customer.country}
                onChange={(e) =>
                  setCustomer((prevObj) => ({
                    ...prevObj,
                    country: e.target.value,
                  }))
                }
              />
            </td>
          </tr>
        </tbody>
      </table>
      <br />
      <p>
        By Register, you agree to our Terms,
        <br />
        Privacy Policy and Cookies Policy.
      </p>
      <button onClick={() => navigate("/")} className="btn btn-secondary">
        Back
      </button>
      <button type="submit" className="btn btn-primary">
        Register
      </button>
      <br />
      <br />
      <p>Already registered?</p>
      <button onClick={() => navigate("/Login")} className="btn btn-primary">
        Login
      </button>
    </form>
  );
};

export default Register;
