import axios from "axios";
import { useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";

const EditCustomerSelf = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { customer } = location.state;  // Retrieve customer details passed from GetCustomer page

  const [updatedCustomer, setUpdatedCustomer] = useState({
    customerId: customer.customerId,
    userName: customer.userName,
    firstName: customer.firstName,
    lastName: customer.lastName,
    email: customer.email,
    password: customer.password,
    phoneNumber: customer.phoneNumber,
    address: customer.address,
    city: customer.city,
    state: customer.state,
    postalCode: customer.postalCode,
    country: customer.country,
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdatedCustomer((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();

    // Make a PUT request to update the customer
    axios
      .put(`http://localhost:5263/api/Customer/UpdateCustomer/${updatedCustomer.customerId}`, updatedCustomer, {
        headers: { Authorization: `Bearer ${sessionStorage.getItem("token")}` }
      })
      .then((response) => {
        console.log("Customer updated successfully", response.data);
        navigate("/GetCustomer");  // Redirect back to the customer details page after successful update
      })
      .catch((error) => console.log(error));
  };

  return (
    <div className="container mt-5">
      <h2>Edit Customer Details</h2>
      <form onSubmit={handleFormSubmit}>
      <div className="mb-3">
          <label className="form-label">User Name</label>
          <input
            type="text"
            className="form-control"
            name="userName"
            value={updatedCustomer.userName}
            onChange={handleInputChange}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">First Name</label>
          <input
            type="text"
            className="form-control"
            name="firstName"
            value={updatedCustomer.firstName}
            onChange={handleInputChange}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Last Name</label>
          <input
            type="text"
            className="form-control"
            name="lastName"
            value={updatedCustomer.lastName}
            onChange={handleInputChange}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Email</label>
          <input
            type="email"
            className="form-control"
            name="email"
            value={updatedCustomer.email}
            onChange={handleInputChange}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Password</label>
          <input
            type="password"
            className="form-control"
            name="password"
            value={updatedCustomer.password}
            onChange={handleInputChange}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Phone Number</label>
          <input
            type="text"
            className="form-control"
            name="phoneNumber"
            value={updatedCustomer.phoneNumber}
            onChange={handleInputChange}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Address</label>
          <input
            type="text"
            className="form-control"
            name="address"
            value={updatedCustomer.address}
            onChange={handleInputChange}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">City</label>
          <input
            type="text"
            className="form-control"
            name="city"
            value={updatedCustomer.city}
            onChange={handleInputChange}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">State</label>
          <input
            type="text"
            className="form-control"
            name="state"
            value={updatedCustomer.state}
            onChange={handleInputChange}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Postal Code</label>
          <input
            type="text"
            className="form-control"
            name="postalCode"
            value={updatedCustomer.postalCode}
            onChange={handleInputChange}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Country</label>
          <input
            type="text"
            className="form-control"
            name="country"
            value={updatedCustomer.country}
            onChange={handleInputChange}
          />
        </div>
        <button type="submit" className="btn btn-primary">Save Changes</button>
      </form>
    </div>
  );
};

export default EditCustomerSelf;
