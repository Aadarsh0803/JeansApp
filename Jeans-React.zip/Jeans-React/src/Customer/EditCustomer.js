import {  useState } from "react";
import axios from "axios";

const EditCustomer = () => {
  const [customer, setCustomer] = useState({
    customerId: "",
    userName: "",
    firstName: "",
    lastName: "",
    role: "",
    email: "",
    password: "",
    phoneNumber: "",
    address: "",
    city: "",
    state: "",
    postalcode: 0,
    country: ""
  });
//var email = customer.email
  const [email, setEmail] = useState(""); // State to store user input email
  const [isEmailSubmitted, setIsEmailSubmitted] = useState(false); // State to check if email is submitted
  const [errorMessage, setErrorMessage] = useState(""); // State to store error message if any

  // Function to handle email submission
  const handleEmailSubmit = (e) => {
    e.preventDefault();
    if (!email) return;

    axios
      .get(`http://localhost:5263/api/Customer/GetCustomerByEmail/${encodeURIComponent(email)}`)
      .then((res) => {
        console.log(res);
        setCustomer(res.data);
        setIsEmailSubmitted(true); // Set flag to true after fetching customer details
        setErrorMessage(""); // Clear error message if request is successful
      })
      .catch((err) => {
        console.log(err);
        setErrorMessage("No customer found with this email."); // Set error message if request fails
      });
  };

  // Function to handle save/update action
  const save = (event) => {
    event.preventDefault();
    console.log(customer);
    axios
      .put(`http://localhost:5263/api/Customer/Update/${encodeURIComponent(email)}`, customer)
      .then((res) => {
        console.log(res.data);
        setErrorMessage(""); // Clear error message if update is successful
      })
      .catch((err) => {
        console.log(err);
        setErrorMessage("Failed to update customer details."); // Set error message if update fails
      });
  };

  return (
    <>
      {!isEmailSubmitted ? (
        <form onSubmit={handleEmailSubmit} className="form-inline mb-3">
          <div className="form-group">
            <label htmlFor="emailInput" className="mr-2">Email: </label>
            <input
              id="emailInput"
              type="text"
              className="form-control mr-2"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <button type="submit" className="btn btn-primary">Fetch Customer</button>
          </div>
          {errorMessage && <div className="alert alert-danger mt-2">{errorMessage}</div>}
        </form>
      ) : (
        <form onSubmit={save} className="form-horizontal">
          <table className="table table-bordered">
            <tbody>
              <tr>
                <td>Customer Id</td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={customer.customerId}
                    onChange={(e) =>
                      setCustomer((prevObj) => ({
                        ...prevObj,
                        customerId: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>User Name</td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={customer.userName}
                    onChange={(e) =>
                      setCustomer((prevObj) => ({
                        ...prevObj,
                        userName: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>First Name</td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={customer.firstName}
                    onChange={(e) =>
                      setCustomer((prevObj) => ({
                        ...prevObj,
                        firstName: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Last Name</td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={customer.lastName}
                    onChange={(e) =>
                      setCustomer((prevObj) => ({
                        ...prevObj,
                        lastName: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Role</td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={customer.role}
                    onChange={(e) =>
                      setCustomer((prevObj) => ({
                        ...prevObj,
                        role: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Email</td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={customer.email}
                    onChange={(e) =>
                      setCustomer((prevObj) => ({
                        ...prevObj,
                        email: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Password</td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={customer.password}
                    onChange={(e) =>
                      setCustomer((prevObj) => ({
                        ...prevObj,
                        password: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Phone Number</td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={customer.phoneNumber}
                    onChange={(e) =>
                      setCustomer((prevObj) => ({
                        ...prevObj,
                        phoneNumber: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Address</td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={customer.address}
                    onChange={(e) =>
                      setCustomer((prevObj) => ({
                        ...prevObj,
                        address: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>City</td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={customer.city}
                    onChange={(e) =>
                      setCustomer((prevObj) => ({
                        ...prevObj,
                        city: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>State</td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={customer.state}
                    onChange={(e) =>
                      setCustomer((prevObj) => ({
                        ...prevObj,
                        state: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Postal Code</td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={customer.postalcode}
                    onChange={(e) =>
                      setCustomer((prevObj) => ({
                        ...prevObj,
                        postalcode: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Country</td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={customer.country}
                    onChange={(e) =>
                      setCustomer((prevObj) => ({
                        ...prevObj,
                        country: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
            </tbody>
          </table>
          <button type="submit" className="btn btn-success mt-3">Update</button>
          {errorMessage && <div className="alert alert-danger mt-2">{errorMessage}</div>}
        </form>
      )}
    </>
  );
};

export default EditCustomer;
