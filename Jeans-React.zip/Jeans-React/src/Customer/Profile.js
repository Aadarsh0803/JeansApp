import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import './Profile.css';

const GetCustomer = () => {
    const [customer, setCustomer] = useState(null); 
    const navigate = useNavigate();

    useEffect(() => {
        const token = sessionStorage.getItem("token");
        if (token) {
            let email = sessionStorage.getItem("email");
            axios
                .get('http://localhost:5263/api/Customer/GetCustomerByEmail/' + email, {
                    headers: { Authorization: `Bearer ${sessionStorage.getItem("token")}` }
                })
                .then((response) => {
                    console.log(response.data);
                    setCustomer(response.data);  
                })
                .catch((error) => console.log(error));
        }
    }, []);

    if (!customer) {
        return <div>Loading...</div>;
    }

    return (
        <>
            <div className="container mt-5">
                <button className="btn btn-secondary" onClick={() => navigate("/WelcomePage")}>Back</button>
                <button className="btn btn-primary edit-btn" onClick={() => navigate("/EditCustomerSelf", {state:{customer}})}>Edit</button>
                <h2 className="text-center mb-4">Customer Details</h2>
                <div className="customer-details">
                    <div className="row mb-3">
                        <div className="col-sm-4"><strong>Customer ID</strong></div>
                        <div className="col-sm-8">{customer.customerId}</div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-sm-4"><strong>Username</strong></div>
                        <div className="col-sm-8 user-name">{customer.userName}</div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-sm-4"><strong>First Name</strong></div>
                        <div className="col-sm-8">{customer.firstName}</div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-sm-4"><strong>Last Name</strong></div>
                        <div className="col-sm-8">{customer.lastName}</div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-sm-4"><strong>Role</strong></div>
                        <div className="col-sm-8">{customer.role}</div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-sm-4"><strong>Email</strong></div>
                        <div className="col-sm-8">{customer.email}</div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-sm-4"><strong>Password</strong></div>
                        <div className="col-sm-8" >{customer.password}</div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-sm-4"><strong>Phone Number</strong></div>
                        <div className="col-sm-8">{customer.phoneNumber}</div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-sm-4"><strong>Address</strong></div>
                        <div className="col-sm-8">{customer.address}</div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-sm-4"><strong>City</strong></div>
                        <div className="col-sm-8">{customer.city}</div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-sm-4"><strong>State</strong></div>
                        <div className="col-sm-8">{customer.state}</div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-sm-4"><strong>Postal Code</strong></div>
                        <div className="col-sm-8">{customer.postalCode}</div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-sm-4"><strong>Country</strong></div>
                        <div className="col-sm-8">{customer.country}</div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default GetCustomer;
