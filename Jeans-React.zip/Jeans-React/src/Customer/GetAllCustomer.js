import axios from 'axios';
import { useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';

const GetAllCustomers = () => {
    const [customers, setCustomers] = useState([]);
    const navigate = useNavigate();
    useEffect(() => {
        const token = sessionStorage.getItem("token");
        if (token) {
            axios.get('http://localhost:5263/api/Customer/GetCustomers', {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            })
            .then((response) => {
                console.log(response.data);
                setCustomers(response.data);
            })
            .catch((error) => console.log(error));
        }
    }, []);

    return (
        <>
        <button className="btn btn-secondary"  onClick={() => navigate("/WelcomeAdmin")}>Back</button>

        <div className="container">
            <table className="table">
                <thead className="table-primary">
                    <tr>
                        <th>CustomerId</th>
                        <th>Username</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Role</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Phone Number</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Postal Code</th>
                        <th>Country</th>
                    </tr>
                </thead>
                <tbody>
                    {customers.map((customer) => (
                        <tr key={customer.customerId}>
                            <td>{customer.customerId}</td>
                            <td>{customer.userName}</td>
                            <td>{customer.firstName}</td>
                            <td>{customer.lastName}</td>
                            <td>{customer.role}</td>
                            <td>{customer.email}</td>
                            <td>{customer.password}</td>
                            <td>{customer.phoneNumber}</td>
                            <td>{customer.address}</td>
                            <td>{customer.city}</td>
                            <td>{customer.state}</td>
                            <td>{customer.postalCode}</td>
                            <td>{customer.country}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
        </>
    );
};

export default GetAllCustomers;
