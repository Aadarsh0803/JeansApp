import axios from "axios";
import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const AddOrder = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const orderItems = location.state.orderItems || [];

  const [selectedItems, setSelectedItems] = useState(orderItems);

  const generateOrderId = () => {
    const randomId = Math.floor(Math.random() * 1000).toString().padStart(3, "0");
    return `O${randomId}`;
  };

  const generateItemId = () => {
    const randomId = Math.floor(Math.random() * 1000).toString().padStart(3, "0");
    return `I${randomId}`;
  };

  const addOrder = async (orderData) => {
    const token = sessionStorage.getItem("token");
    try {
      const response = await axios.post('http://localhost:5263/api/Order/AddOrder', orderData, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      console.log("Order added:", response.data);
      return response.data.orderId;
    } catch (error) {
      console.error("Error adding order:", error);
    }
  };

  const addOrderItem = async (orderItemData) => {
    const token = sessionStorage.getItem("token");
    try {
      const response = await axios.post('http://localhost:5263/api/OrderItem/AddOrderItem', orderItemData, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      console.log("Order item added:", response.data);
    } catch (error) {
      console.error("Error adding order item:", error);
    }
  };

  const handleAddOrder = async () => {
    const orderId = generateOrderId();
    const customerId = sessionStorage.getItem("id");
  navigate("/GetOrders");
      selectedItems.reduce((acc, item) => {
      const itemTotal = (item.price - (item.price * item.discount) / 100) * item.quantity;
      return acc + itemTotal;
      
    }, 0);
  
    const orderData = {
      orderId,
      orderDate: new Date().toISOString(),
      customerId,
      orderStatus: "Pending",
    };
  
    try {
      await addOrder(orderData);
  
      for (const item of selectedItems) {
        const orderItemData = {
          itemId: generateItemId(),
          orderId,
          productId: item.productId,
          price: item.price,
          discount: item.discount,
          quantity: item.quantity || 1,
        };
  
        await addOrderItem(orderItemData);
      }
  
      alert("Order placed successfully!");
  
    } catch (error) {
      console.error("Error placing the order:", error);
      alert("Failed to place the order. Please try again.");
    }
  };
  


  const handleQuantityChange = (productId, quantity) => {
    setSelectedItems((prevItems) =>
      prevItems.map((item) =>
        item.productId === productId ? { ...item, quantity: parseInt(quantity, 10) } : item
      )
    );
  };


  return (
    <div className="container mt-5">
      <button onClick={()=>navigate("/WelcomePage")}>Back</button>
      <h2 className="text-center mb-4">Order Summary</h2>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Price</th>
            <th>Discount</th>
            <th>Quantity</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          {selectedItems.map((item) => (
            <tr key={item.productId}>
              <td>{item.productName}</td>
              <td>{item.price}</td>
              <td>{item.discount}%</td>
              <td>
                <input
                  type="number"
                  value={item.quantity || 1}
                  onChange={(e) => handleQuantityChange(item.productId, e.target.value)}
                  min="1"
                />
              </td>
              <td>{(item.price - (item.price * item.discount) / 100) * item.quantity}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="text-center mt-4">
        {/* <h4>Total Amount: {totalCost}</h4> */}
        <button className="btn btn-success" onClick={handleAddOrder}>
          Place Order
        </button>
      </div>
    </div>
  );
};

export default AddOrder;
