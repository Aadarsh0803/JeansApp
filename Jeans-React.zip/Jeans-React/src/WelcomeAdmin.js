import React from "react";
import { Link, Outlet } from "react-router-dom";

function WelcomeAdmin() {
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                <div className="container-fluid">
                    <Link className="navbar-brand" to="/dashboard">Admin Dashboard</Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarNav">
                        <ul className="navbar-nav ms-auto">
                            <li className="nav-item">
                                <Link className="nav-link" to="/AddProduct">Add Product</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/GetAllProductsAdmin">Get Products</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/OrdersAdmin">Get Orders</Link>
                            </li>
                            {/* <li className="nav-item">
                                <Link className="nav-link" to="/ProductList">Filter Product</Link>
                            </li> */}
                            <li className="nav-item">
                                <Link className="nav-link" to="/GetAllCustomers">Get All Customers</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link text-danger" to="/logout">Logout</Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <main className="container mt-4">
                <Outlet />
                <div className="text-center mt-4">
                    <h1>Hello, Admin!</h1>
                    <p>Have a Nice Day</p>
                </div>
            </main>
        </div>
    );
}

export default WelcomeAdmin;
