import axios from "axios";
import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";

const Transaction = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // Get orderId and amount from location state (passed from GetOrders)
  const { orderId, amount } = location.state || {};
  console.log("Received orderId:", orderId);
  console.log("Received amount:", amount);



  // Handle form submission (save transaction)
  const save = async (e) => {
    e.preventDefault();
    console.log("Transaction data before sending:", transaction);

    try {
      const response = await axios.post("http://localhost:5263/api/Transaction/AddTransaction", transaction, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      });
      console.log("Response from AddTransaction:", response.data);
      const transactionId = response.data.transactionId;
      setTransaction((prevTransaction)=>({
        ...prevTransaction,
        transactionId:transactionId,
      }));
      alert("Transaction Successful");
      navigate("/GetTransaction");
    } catch (err) {
      console.error("Error during transaction:", err);
    }
  };
    // Initial transaction state
  const [transaction, setTransaction] = useState({
    orderId: orderId || "",
    customerId: sessionStorage.getItem("id"), 
    amount: 0,  // Use the amount passed from GetOrders
    transactionMethod: "",
    transactionDate: new Date().toISOString(),
  });


  // Handle input changes for form fields
  const handleChange = (e) => {
    const { name, value } = e.target;
    console.log(`Input change - ${name}:`, value);
    
    setTransaction((prevTransaction) => ({
      ...prevTransaction,
      [name]: value,
    }));
  };



  return (
    <div className="container">
      <h2>Transaction</h2>
      <form onSubmit={save}>
        <div className="mb-3">
          <label htmlFor="transactionId" className="form-label">Transaction ID</label>
          <input
            type="text"
            className="form-control"
            id="transactionId"
            name="transactionId"
            value={transaction.transactionId}
            readOnly
          />
        </div>
        <div className="mb-3">
          <label htmlFor="orderId" className="form-label">Order ID</label>
          <input
            type="text"
            className="form-control"
            id="orderId"
            name="orderId"
            value={transaction.orderId}
            readOnly
          />
        </div>

        <div className="mb-3">
          <label htmlFor="customerId" className="form-label">Customer ID</label>
          <input
            type="text"
            className="form-control"
            id="customerId"
            name="customerId"
            value={transaction.customerId}
            readOnly
          />
        </div>


        <div className="mb-3">
          <label htmlFor="amount" className="form-label">Amount</label>
          <input
            type="number"
            className="form-control"
            id="amount"
            name="amount"
            value={transaction.amount}
            onChange={handleChange}
            
          />
        </div>

        <div className="mb-3">
          <label htmlFor="transactionMethod" className="form-label">Transaction Method</label>
          <select
            className="form-select"
            id="transactionMethod"
            name="transactionMethod"
            value={transaction.transactionMethod}
            onChange={handleChange}
            required
          >
            <option value="">Select Payment Method</option>
            <option value="COD">Cash on Delivery (COD)</option>
            <option value="GPAY">Google Pay (GPay)</option>
            <option value="PHONEPE">PhonePe</option>
            <option value="PAYTM">Paytm</option>
            <option value="CARD">Credit/Debit Card</option>
          </select>
        </div>

        <div className="mb-3">
          <label htmlFor="transactionDate" className="form-label">Transaction Date</label>
          <input
            type="text"
            className="form-control"
            id="transactionDate"
            name="transactionDate"
            value={transaction.transactionDate}
            readOnly
          />
        </div>

        <button type="submit" className="btn btn-primary">Make Payment</button>
      </form>
    </div>
  );
};

export default Transaction;
