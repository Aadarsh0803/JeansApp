import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useLocation } from 'react-router-dom';

const GetTransactions = () => {
  const [transactions, setTransactions] = useState([]);
  const location = useLocation();

  // Get orderId from location state (passed from previous component)
  const { orderId } = location.state || {};

  useEffect(() => {
    if (orderId) {
      // Fetch transaction data from backend based on orderId
      axios.get(`http://localhost:5263/api/Transaction/GetTransactionsByOrderId/${orderId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem('token')}`,
        },
      })
      .then((res) => {
        console.log("Received transactions:", res.data);
        setTransactions(res.data);
      })
      .catch((err) => console.error("Error fetching transactions:", err));
    }
  }, [orderId]);

  return (
    <div className="container mt-4">
      <h2>Transactions for Order ID: {orderId}</h2>
      {transactions.length > 0 ? (
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Transaction ID</th>
              <th>Order ID</th>
              <th>Customer ID</th>
              <th>Amount</th>
              <th>Transaction Method</th>
              <th>Transaction Date</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction) => (
              <tr key={transaction.transactionId}>
                <td>{transaction.transactionId}</td>
                <td>{transaction.orderId}</td>
                <td>{transaction.customerId}</td>
                <td>{transaction.amount}</td>
                <td>{transaction.transactionMethod}</td>
                <td>{new Date(transaction.transactionDate).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No transactions found for this order.</p>
      )}
    </div>
  );
};

export default GetTransactions;
