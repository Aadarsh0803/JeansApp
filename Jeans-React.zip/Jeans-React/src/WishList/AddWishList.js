import React, { useEffect, useState } from "react";
import axios from "axios";
import { useLocation, useNavigate } from "react-router-dom";

const AddWish = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const product = location.state?.product;
  
    const [addWish, setWish] = useState({
        wishId: "W" + Math.floor(Math.random()),
        productId: product?.productId,
        customerId: sessionStorage.getItem("id"),
    });
  
    const [isInWishList, setIsInWishList] = useState(false);
  
    useEffect(() => {
        if (!product) {
            alert("No product selected! Redirecting...");
            navigate("/GetAllProducts");
        } else {
            checkIfProductInWishList(product.productId);
        }
    }, [product, navigate]);
  
    const checkIfProductInWishList = (productId) => {
        axios
            .get(`http://localhost:5263/api/WishList/check/${productId}`, {
                headers: {
                    Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                },
            })
            .then((res) => {
                setIsInWishList(res.data.isInWishList);
            })
            .catch((err) => {
                console.error("Error checking wish list:", err.response?.data || err.message);
            });
    };
  
    const saveToWish = () => {
        if (isInWishList) {
            alert("Product is already in your wish list.");
            return;
        }
  
        axios
            .post("http://localhost:5263/api/WishList", addWish, {
                headers: {
                    Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                },
            })
            .then((res) => {
                console.log("Response from server:", res.data);
                alert("Product added to wish list!");
                navigate("/GetAllProducts");
            })
            .catch((err) => {
                console.error("Error adding product to wish:", err.response?.data || err.message);
            });
    };
  
    return (
        <div>
            {/* Add form or buttons to handle adding to wish list */}
            <button onClick={saveToWish}>Save to Wish List</button>
        </div>
    );
};

export default AddWish;
