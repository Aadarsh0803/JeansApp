import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import './GetWishList.css'

const GetWishList = () => {
  const [wishlist, setWishList] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const token = sessionStorage.getItem("token");
    const id = sessionStorage.getItem("id");
    if (token) {
      axios
        .get("http://localhost:5263/api/WishList/" + id, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })
        .then((response) => {
          console.log(response.data);
          setWishList(response.data);
        })
        .catch((error) => console.log(error));
    }
  }, []);

  return (
    <div className="wishlist-container container mt-5">
      <button
        className="btn btn-secondary back-button"
        onClick={() => navigate("/WelcomePage")}
      >
        Back
      </button>
      <h2>Wishlist</h2>
      <table className="table table-bordered table-hover">
        <thead className="table-primary">
          <tr>
            <th>Product Name</th>
            <th>Product Description</th>
            <th>Gender</th>
            <th>Cloth Type</th>
            <th>Age Group</th>
            <th>Price</th>
            <th>Discount</th>
            <th>Size</th>
            <th>Color</th>
            <th>Brand</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {wishlist.map((item) => (
            <tr key={item.productId}>
              <td>{item.product.productName}</td>
              <td>{item.product.productDescription}</td>
              <td>{item.product.gender}</td>
              <td>{item.product.cloth}</td>
              <td>{item.product.age}</td>
              <td>{item.product.price}</td>
              <td>{item.product.discount}</td>
              <td>{item.product.size}</td>
              <td>{item.product.color}</td>
              <td>{item.product.brand}</td>
              <td>
                <button
                  className="btn btn-danger"
                  onClick={() => navigate("/DeleteWish")}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default GetWishList;
