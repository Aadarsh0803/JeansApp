import { useState, useEffect } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import AddWish from "./AddWishList";

const DeleteWish = () => {
  const [productId, setProductId] = useState("");
  const [product, setProduct] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");

  const id = sessionStorage.getItem("id"); 

  useEffect(() => {
    if (id) {
      axios
        .get(`http://localhost:5263/api/WishList/${id}`, {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem('token')}`,
          },
        })
        .then((res) => {
          setProduct(res.data);
        })
        .catch((err) => {
          console.log(err);
          setErrorMessage("Error fetching product details.");
        });
    }
  }, [id]);
const wishId = sessionStorage.getItem("wishId");
  const deleteProduct = () => {
    if (window.confirm("Are you sure you want to delete this product?")) {
      axios
        .delete(`http://localhost:5263/api/WishList/deleteWish/${wishId}`, {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem('token')}`,
          },
        })
        .then(() => {
          setProduct(null);
          setProductId("");
          alert("Product deleted successfully.");
        })
        .catch((err) => {
          console.log(err);
          setErrorMessage("Error deleting product.");
        });
    }
  };

  return (
    <div className="container mt-4">
      {errorMessage && <div className="alert alert-danger">{errorMessage}</div>}

      {product ? (
        <div>          
          <button className="btn btn-danger mt-3" onClick={deleteProduct}>Delete Product</button>
        </div>
      ) : (
        <div>No product details available.</div>
      )}
    </div>
  );
};

export default DeleteWish;
