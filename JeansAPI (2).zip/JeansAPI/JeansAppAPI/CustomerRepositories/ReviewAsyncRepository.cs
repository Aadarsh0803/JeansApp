﻿using JeansAppAPI.DTO;
using JeansAppAPI.Entities;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

namespace JeansAppAPI.CustomerRepositories
{
    public class ReviewAsyncRepository:IReviewAsyncRepository
    {
        private readonly JeansContext _context;

        public ReviewAsyncRepository(JeansContext context)
        {
            _context = context;
        }

        public async Task<Review> AddReview(Review review)
        {
           await _context.AddAsync(review);
            await _context.SaveChangesAsync();
            return review;
        }

        public async Task DeleteReview(string Id)
        {
            var review = await _context.Reviews.FindAsync(Id);
            if (review != null)
            {
                _context.Reviews.Remove(review);
                await _context.SaveChangesAsync();
            }
            else
            {
                Console.WriteLine("No Review Found");
            }
        }

        public async Task<List<Review>> GetAllReviewsById(string ProductId)
        {
            var review = await _context.Reviews
                    .Where(r => r.ProductId == ProductId)
                    .ToListAsync(); 
            if (review == null)
            {
                Console.WriteLine($"Review on {ProductId} is Empty");
            }
            return review;
        }

        public async Task<Review> UpdateReview(Review review)
        {
            var _review = await _context.Reviews.FindAsync(review.ReviewId);
            if(_review == null)
            {
                Console.WriteLine("No Review found");
                return null;
            }
            _review.ProductId = review.ProductId;
            _review.CustomerId = review.CustomerId;
            _review.Description = review.Description;
            if(review.Ratings>5 || review.Ratings < 1)
            {
                throw new Exception("Ratings must be in between 1-5");
            }
            else
            {
                _review.Ratings = review.Ratings;
            }
            await _context.SaveChangesAsync();
            return _review;
        }
    }
}
