﻿using JeansAppAPI.Entities;
using System.ComponentModel.DataAnnotations;

namespace JeansAppAPI.UserRepository
{
    public interface ICustomerRepository
    {
        public  Task Add(Customer customer);
        public Task Update(Customer customer);
        public Task<Customer> GetByEmail(string email);
        public Task<Customer> FindByEmail(string email);
        Task<List<Customer>> GetAll();
        public Task Delete(string email);
        Task<Customer> ValidUser(string username, string email, string password);
    }
}
