﻿using JeansAppAPI.DTO;
using JeansAppAPI.Entities;
using Microsoft.EntityFrameworkCore;

namespace JeansAppAPI.CustomerRepositories
{
    public class OrderItemAsyncRepository : IOrderItemAsyncRepository
    {
        private readonly JeansContext _context;
        public OrderItemAsyncRepository(JeansContext context)
        {
            _context = context;
        }

        public async Task<OrderItem> AddOrderItem(OrderItemDTO orderItemDTO)
        {
            var product = await _context.Products.FindAsync(orderItemDTO.ProductId);
            if (product == null)
            {
                throw new Exception("No Product Found");
            }
            var item = new OrderItem
            {
                ItemId = orderItemDTO.ItemId,
                OrderId = orderItemDTO.OrderId,
                ProductId = orderItemDTO.ProductId,
                Price = product.Price,
                Discount = product.Discount,
                Quantity = orderItemDTO.Quantity
            };
            await _context.OrderItems.AddAsync(item);
            await _context.SaveChangesAsync();
            return item;
        }

        public async Task DeleteOrderItem(string orderItemId)
        {
            var item = await _context.OrderItems.FindAsync(orderItemId);
            if (item != null)
            {
                _context.OrderItems.Remove(item);
                await _context.SaveChangesAsync();
            }
        }

        /*        public async Task<List<OrderItem>> GetOrderItemById(string orderItemId)
                {
                    return await _context.OrderItems.Include(o=>o.Product).Where(o => o.OrderId == orderItemId).ToListAsync();
                }*/
        public async Task<List<OrderItemDTO>> GetOrderItemById(string orderItemId)
        {
            return await _context.OrderItems
                .Where(o => o.OrderId == orderItemId)
                .Select(o => new OrderItemDTO
                {
                    ItemId = o.ItemId,
                    OrderId = o.OrderId,
                    ProductId = o.ProductId,
                    Price = o.Price,
                    Discount = o.Discount,
                    Quantity = o.Quantity
                })
                .ToListAsync();
        }

    }
}
