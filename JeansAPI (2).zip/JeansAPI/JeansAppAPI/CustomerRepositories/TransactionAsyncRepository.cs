﻿using JeansAppAPI.DTO;
using JeansAppAPI.Entities;
using Microsoft.EntityFrameworkCore;

namespace JeansAppAPI.CustomerRepositories
{
    public class TransactionAsyncRepository : ITransactionAsyncRepository
    {
        private readonly JeansContext _context;

        public TransactionAsyncRepository(JeansContext context)
        {
            _context = context;
        }

        public async Task<Transaction1> AddTransaction(TransactionDTO transactiondto)
        {
            decimal totalAmount = await _context.OrderItems
                .Where(o => o.OrderId == transactiondto.OrderId)
                .SumAsync(o => o.Quantity * o.Price * (1 - o.Discount / 100));

            var transaction = new Transaction1
            {
                TransactionId = Guid.NewGuid(),
                CustomerId = transactiondto.CustomerId,
                OrderId = transactiondto.OrderId,
                TransactionMethod = transactiondto.TransactionMethod,
                TransactionDate = transactiondto.TransactionDate,
                Amount = totalAmount
            };

            await _context.Transactions.AddAsync(transaction);
            await _context.SaveChangesAsync();
            return transaction;
        }
        public async Task DeleteTransaction(string orderId)
        {
            var transaction = await _context.Transactions.FirstOrDefaultAsync(t => t.OrderId == orderId);

            if (transaction == null)
            {
                throw new ArgumentException("Transaction not found");
            }

            _context.Transactions.Remove(transaction);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Transaction1>> GetTransactionByOrderId(string orderId)
        {
            var transactionlist = await _context.Transactions.Where(q => q.OrderId == orderId).ToListAsync();
            return transactionlist;
        }
    }
}
