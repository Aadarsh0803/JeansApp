﻿using JeansAppAPI.DTO;
using JeansAppAPI.Entities;

namespace JeansAppAPI.CustomerRepositories
{
    public interface ITransactionAsyncRepository
    {
        public Task<Transaction1> AddTransaction(TransactionDTO transactionDTO);
        public Task<List<Transaction1>> GetTransactionByOrderId(string orderId);
        public Task DeleteTransaction(string orderId);
    }
}
