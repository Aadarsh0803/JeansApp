﻿using JeansAppAPI.Entities;

namespace JeansAppAPI.CustomerRepositories
{
    public interface ICartAsyncRepository
    {
        public Task<List<Cart>> GetCartList(string customerId);
        public Task<Cart> Add(Cart cart);
        public Task DeleteCart(Guid cartId);
    }
}
