﻿using JeansAppAPI.Entities;
using Microsoft.EntityFrameworkCore;

namespace JeansAppAPI.UserRepository
{
    public class Customerrepository : ICustomerRepository
    {
        private readonly JeansContext _context;
        public Customerrepository(JeansContext context)
        {
            _context = context;
        }
        /*private readonly JeansContext _context;

        public CustomerRepository ()
        {
            _context = new JeansContext();
        }*/
        public async Task Add(Customer customer)
        {
            await _context.Customers.AddAsync(customer);
            await _context.SaveChangesAsync();
        }



        public async Task<List<Customer>> GetAll()
        {
            var customers = await _context.Customers.ToListAsync();
            return customers;
        }
        public async Task<Customer> FindByEmail(string email)
        {
            var customer = await _context.Customers.SingleOrDefaultAsync(q=>q.Email ==  email);
            return customer;
        }

        public async Task Delete(string email)
        {
            var customer = await _context.Customers.SingleOrDefaultAsync(q => q.Email == email);
            if (customer == null)
            {
                // Handle case where the customer was not found
                throw new ArgumentException("Customer not found", nameof(email));
            }

            _context.Customers.Remove(customer);
            await _context.SaveChangesAsync();
        }
        public async Task Update(Customer customer)
        {
            _context.Customers.Update(customer);
            await _context.SaveChangesAsync();
        }

        public async Task<Customer> ValidUser(string username, string email, string password)
        {
            var user = await _context.Customers.SingleOrDefaultAsync(q=>q.Email == email && q.Password == password || q.UserName == username && q.Password == password);
            return user;
        }

        public async Task<Customer> GetByEmail(string email)
        {
            var customer = await _context.Customers
                                         .FirstOrDefaultAsync(c => c.Email == email);

            if (customer == null)
            {
                throw new ArgumentException("Customer not found", nameof(email));
            }

            return customer;
        }

    }
}
