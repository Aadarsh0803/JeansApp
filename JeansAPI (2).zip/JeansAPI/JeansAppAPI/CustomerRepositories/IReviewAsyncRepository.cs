﻿using JeansAppAPI.DTO;
using JeansAppAPI.Entities;

namespace JeansAppAPI.CustomerRepositories
{
    public interface IReviewAsyncRepository
    {
        public Task<Review> AddReview(Review review);
        public Task DeleteReview(string Id);
        public Task<Review> UpdateReview(Review review);
        public Task<List<Review>> GetAllReviewsById(string ProductId);
    }

}
