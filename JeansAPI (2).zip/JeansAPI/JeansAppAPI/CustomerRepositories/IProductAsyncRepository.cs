﻿using JeansAppAPI.Entities;
using System.Globalization;

namespace JeansAppAPI.CustomerRepository
{
    public interface IProductAsyncRepository
    {
        public Task AddProduct(Product product);
        public Task DeleteProduct(string ProductId);
        public Task UpdateProduct(Product product);
        public Task<Product> GetById(string ProductId);
        public Task<List<Product>> GetAllProducts();
        public Task<List<Product>> GetProductByCategory(string? Gender, string? cloth, string? age, int? size, String? color, string? Brand);


    }
}
