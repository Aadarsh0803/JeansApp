﻿using JeansAppAPI.DTO;
using JeansAppAPI.Entities;

namespace JeansAppAPI.CustomerRepositories
{
    public interface IOrderItemAsyncRepository
    {
        Task<OrderItem> AddOrderItem(OrderItemDTO orderItemDTO);
        Task DeleteOrderItem(string orderItemId);
        Task<List<OrderItemDTO>> GetOrderItemById(string orderItemId);
    }
}
