﻿using JeansAppAPI.Entities;
using Microsoft.EntityFrameworkCore;

namespace JeansAppAPI.CustomerRepositories
{
    public class CartAsyncRepository : ICartAsyncRepository
    {
        private readonly JeansContext _context;

        public CartAsyncRepository(JeansContext context)
        {
            _context = context;
        }
        public async Task<Cart> Add(Cart cart)
        {
            var existingCartItem = await _context.Carts
                .FirstOrDefaultAsync(c => c.ProductId == cart.ProductId && c.CustomerId == cart.CustomerId);

            if (existingCartItem != null)
            {
                throw new Exception("Product is already in the cart.");
            }

            cart.CartId = Guid.NewGuid();
            await _context.Carts.AddAsync(cart);
            await _context.SaveChangesAsync();
            return cart;
        }


        public async Task DeleteCart(Guid cartId)
        {
            var cart = await _context.Carts
                .Where(c => c.CartId == cartId)
                .FirstOrDefaultAsync();

            if (cart == null)
            {
                throw new Exception("No Items in Cart!!");
            }

            _context.Carts.Remove(cart);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Cart>> GetCartList(string customerId)
        {
            return await _context.Carts
                .Where(q => q.CustomerId == customerId)
                .Include(q => q.Product)
                .ToListAsync();
        }
    }
}
