﻿using JeansAppAPI.DTO;
using JeansAppAPI.Entities;
using Microsoft.EntityFrameworkCore;
using static JeansAppAPI.CustomerRepositories.OrderAsyncRepository;

namespace JeansAppAPI.CustomerRepositories
{
    public class OrderAsyncRepository : IOrderAsyncRepository
    {
        private readonly JeansContext _context;

        public OrderAsyncRepository(JeansContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Order>> GetAllOrdersAsync()
        {
            return await _context.Orders.Include(o => o.Customer).Include(o=>o.OrderItems).ToListAsync();
        }

        public async Task<List<Order>> GetOrderByIdAsync(string CustomerId)
        {
            return await _context.Orders.Include(o => o.Customer).Include(o=>o.OrderItems).Where(o => o.CustomerId == CustomerId).ToListAsync();
        }


        // This method should remain in your repository or service layer
        public async Task<Order> AddOrderAsync(OrderDTO orderDto)
        {
            var order = new Order
            {
                OrderId = orderDto.OrderId,
                CustomerId = orderDto.CustomerId,
                DateOfDelivery = orderDto.OrderDate,
                OrderStatus = orderDto.orderStatus
            };

            // Save the order to the database using the DbContext or similar
            _context.Orders.Add(order);
            await _context.SaveChangesAsync();

            return order;
        }

        public async Task<Order> UpdateOrderAsync(OrderDTO orderDto)
        {
            var order = new Order
            {
                OrderId = orderDto.OrderId,
                CustomerId = orderDto.CustomerId,
                DateOfDelivery = orderDto.OrderDate,
                OrderStatus = orderDto.orderStatus
            };
            _context.Update(order);
            await _context.SaveChangesAsync();
            return order;
        }

        public async Task DeleteOrderAsync(string orderId)
        {
            var order = await _context.Orders.FindAsync(orderId);
            if (order != null)
            {
                _context.Orders.Remove(order);
                await _context.SaveChangesAsync();
            }
        }
    }
}
