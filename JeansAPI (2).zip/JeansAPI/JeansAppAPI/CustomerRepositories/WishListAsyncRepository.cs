﻿using JeansAppAPI.Entities;

using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

namespace JeansAppAPI.CustomerRepositories
{
    public class WishListAsyncRepository:IWishListAsyncRepository
    {
        private readonly JeansContext _context;

        public WishListAsyncRepository(JeansContext context)
        {
            _context = context;
        }

        public async Task<WishList> AddWishList(WishList wishList)
        {
            wishList.WishListId = Guid.NewGuid();
            await _context.Wishes.AddAsync(wishList);
            await _context.SaveChangesAsync();
            return wishList;
        }

        public async Task DeleteWishList(Guid wishId)
        {
            var wish = await _context.Wishes.Where(q=>q.WishListId == wishId).FirstOrDefaultAsync();
            if (wish != null)
            {
                _context.Wishes.Remove(wish);
                await _context.SaveChangesAsync();
            }            
        }

        public async Task<List<WishList>> GetWishList(string customerId)
        {            
            return await _context.Wishes
                             .Where(o => o.customerId == customerId)
                             .Include(o => o.product)
                             .ToListAsync();             
        }
    }
}
