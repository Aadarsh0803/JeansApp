﻿using JeansAppAPI.DTO;
using JeansAppAPI.Entities;
using Microsoft.VisualBasic;

namespace JeansAppAPI.CustomerRepositories
{
    public interface IOrderAsyncRepository
    {
        Task<IEnumerable<Order>> GetAllOrdersAsync();
        Task<List<Order>> GetOrderByIdAsync(string CusstomerId);
        Task<Order> AddOrderAsync(OrderDTO order);
        Task<Order> UpdateOrderAsync(OrderDTO order);
        Task DeleteOrderAsync(string orderId);
    }
}
