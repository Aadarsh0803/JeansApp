﻿using JeansAppAPI.Entities;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using System.Drawing;

namespace JeansAppAPI.CustomerRepository
{
    public class ProductAsyncRepository : IProductAsyncRepository
    {
        private readonly JeansContext _context;

        public ProductAsyncRepository(JeansContext context)
        {
            _context = context;
        }
        public async Task AddProduct(Product product)
        {
            await _context.AddAsync(product);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteProduct(string id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                throw new KeyNotFoundException("Product not found.");
            }
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Product>> GetAllProducts()
        {
            return await _context.Products.ToListAsync();
        }

        public async Task<Product> GetById(string ProductId)
        {
            var product =await _context.Products.SingleOrDefaultAsync(o => o.ProductId == ProductId);
            return product;
        }


        public async Task<List<Product>> GetProductByCategory(string? gender, string? cloth, string? age, int? size, string? color, string? brand)
        {
            var query = _context.Products.AsQueryable();
            if (!string.IsNullOrEmpty(gender))
            {
                query = query.Where(q => q.Gender == gender);
            }

            if (!string.IsNullOrEmpty(cloth))
            {
                query = query.Where(q => q.Cloth == cloth);
            }

            if (!string.IsNullOrEmpty(age))
            {
                query = query.Where(q => q.Age == age);
            }
            if (size.HasValue)
            {
                query = query.Where(q => q.Size == size.Value);
            }

            if (!string.IsNullOrEmpty(color))
            {
                query = query.Where(q => q.Color == color);
            }

            if (!string.IsNullOrEmpty(brand))
            {
                query = query.Where(q => q.Brand == brand);
            }

            var result = await query.ToListAsync();

            if (result.Count > 0)
            {
                return result;
            }
            else
            {
                throw new Exception("No products found matching the criteria.");
            }
        }

        public async Task UpdateProduct(Product product)
        {
            _context.Products.Update(product);
            await _context.SaveChangesAsync();
        }
    }
}
