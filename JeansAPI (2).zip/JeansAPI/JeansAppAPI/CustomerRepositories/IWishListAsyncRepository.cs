﻿using JeansAppAPI.Entities;

namespace JeansAppAPI.CustomerRepositories
{
    public interface IWishListAsyncRepository
    {
        public Task<List<WishList>> GetWishList(string customerId);
        public Task<WishList> AddWishList(WishList wishList);
        public Task DeleteWishList(Guid wishId);

    }
}
