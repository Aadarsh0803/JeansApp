﻿using JeansAppAPI.CustomerRepositories;
using JeansAppAPI.DTO;
using JeansAppAPI.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace JeansAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReviewController : ControllerBase
    {
        private readonly IReviewAsyncRepository reviewAsyncRepository;
        private IConfiguration _configuration;
        public ReviewController(IReviewAsyncRepository reviewAsyncRepository, IConfiguration configuration)
        {
            this.reviewAsyncRepository = reviewAsyncRepository;
            _configuration = configuration;
        }

        [HttpGet,Route("GetReviewsByProductId")]
        [AllowAnonymous]
        public async Task<IActionResult> GetReviewsById(string id)
        {
            try
            {
                var review = await reviewAsyncRepository.GetAllReviewsById(id);
                return Ok(review);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
                
            }
        }

        [HttpPost,Route("AddReview")]
        [Authorize(Roles ="Customer")]
        public async Task<IActionResult> AddReview(ReviewDTO review)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); 
            }
            try
            {
                var reviewEntity = new Review
                {
                    ReviewId = Guid.NewGuid(),
                    ProductId = review.ProductId,
                    CustomerId = review.CustomerId,
                    Description = review.Description,
                    Ratings = review.Ratings
                };
                await reviewAsyncRepository.AddReview(reviewEntity);
                return Ok(reviewEntity);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }

        }
        [HttpPut, Route("UpdateReview")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> UpdateReview(ReviewDTO review)
        {
            try
            {
                var reviewEntity = new Review
                {
                    ReviewId = Guid.Parse(review.ReviewId),
                    ProductId = review.ProductId,
                    CustomerId = review.CustomerId,
                    Description = review.Description,
                    Ratings = review.Ratings
                };
                await reviewAsyncRepository.UpdateReview(reviewEntity);
                return Ok(reviewEntity);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);                
            }
        }

        [HttpDelete,Route("DeleteReview")]
        [Authorize(Roles ="Customer,Admin")]
        public async Task<IActionResult> DeleteReview(string id)
        {
            try
            {
                await reviewAsyncRepository.DeleteReview(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
