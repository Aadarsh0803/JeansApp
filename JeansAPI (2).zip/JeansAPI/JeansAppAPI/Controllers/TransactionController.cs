﻿using JeansAppAPI.CustomerRepositories;
using JeansAppAPI.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;



namespace JeansAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
        private readonly ITransactionAsyncRepository _transactionAsyncRepository;
        public TransactionController(ITransactionAsyncRepository transactionAsyncRepository)
        {
            _transactionAsyncRepository = transactionAsyncRepository;
        }

        [HttpGet, Route("GetTransactionsByOrderId/{OrderId}")]
        [Authorize(Roles ="Admin,Customer")]
        public async Task<IActionResult> Get(string OrderId)
        {
            var transactionList = await _transactionAsyncRepository.GetTransactionByOrderId(OrderId);
            return Ok(transactionList);
        }
        [HttpPost, Route("AddTransaction")]
        [Authorize(Roles ="Customer")]
        public async Task<IActionResult> AddTransaction(TransactionDTO transactionDTO)
        {
            var transaction = await _transactionAsyncRepository.AddTransaction(transactionDTO);
            return StatusCode(200,transaction);
        }

        [HttpDelete, Route("DeleteTeansaction/{orderId}")]
        [Authorize(Roles ="Customer")]
        public async Task<IActionResult> DeleteTransaction(string orderId)
        {
            if (orderId == null)
            {
                return BadRequest("No Transaction Found");
            }
            await _transactionAsyncRepository.DeleteTransaction(orderId);
            return Ok();
        }
    }
}
