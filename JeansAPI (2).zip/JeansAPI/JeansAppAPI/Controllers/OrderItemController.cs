﻿using JeansAppAPI.CustomerRepositories;
using JeansAppAPI.DTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;


namespace JeansAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderItemController : ControllerBase
    {
        private readonly IOrderItemAsyncRepository _orderItemAsyncRepository;

        public OrderItemController(IOrderItemAsyncRepository orderItemAsyncRepository)
        {
            _orderItemAsyncRepository = orderItemAsyncRepository;
        }

        [HttpGet, Route("GetItemById/{OrderId}")]
        [Authorize(Roles ="Admin,Customer")]
        public async Task<IActionResult> GetItemById(string OrderId)
        {
            var item = await _orderItemAsyncRepository.GetOrderItemById(OrderId);
            return Ok(item);
        }
        [HttpPost, Route("AddOrderItem")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> AddOrderItem(OrderItemDTO orderItemDTO)
        {
            try
            {
                var item = await _orderItemAsyncRepository.AddOrderItem(orderItemDTO);
                return Ok(item);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete, Route("DeleteItem")]
        [Authorize(Roles = "Customer")]

        public async Task<IActionResult> Delete(string id)
        {
            await _orderItemAsyncRepository.DeleteOrderItem(id);
            return Ok();
        }
    }
}
