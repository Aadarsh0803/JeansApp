﻿using JeansAppAPI.CustomerRepositories;
using JeansAppAPI.DTO;
using JeansAppAPI.Entities;
using JeansAppAPI.UserRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace JeansAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderAsyncRepository _orderRepository;

        public OrderController(IOrderAsyncRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }

        [HttpGet]
        [Route("GetAllOrders")]
        [Authorize(Roles = "Admin,Customer")]

        public async Task<IActionResult> GetAllOrders()
        {
            return Ok(await _orderRepository.GetAllOrdersAsync());
        }

        [HttpGet]
        [Route("GetOrder/{CustomerId}")]
        [Authorize(Roles = "Customer")]

        public async Task<IActionResult> GetOrder(string CustomerId)
        {
            return Ok(await _orderRepository.GetOrderByIdAsync(CustomerId));
        }

        [HttpPost]
        [Route("AddOrder")]
        [Authorize(Roles = "Customer")]


        public async Task<IActionResult> AddOrder(OrderDTO orderDto)
        {
            try
            {
                var result = await _orderRepository.AddOrderAsync(orderDto);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest("Order could not be added.");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }



        [HttpPut]
        [Route("UpdateOrder")]
        [Authorize(Roles = "Customer")]

        public async Task<IActionResult> UpdateOrder(OrderDTO order)
        {
            return Ok(await _orderRepository.UpdateOrderAsync(order));
        }

        [HttpDelete]
        [Route("DeleteOrder/{OrderId}")]
        [Authorize(Roles = "Customer")]

        public async Task<IActionResult> DeleteOrder(string OrderId)
        {
            await _orderRepository.DeleteOrderAsync(OrderId);
            return NoContent();
        }
    }
}
