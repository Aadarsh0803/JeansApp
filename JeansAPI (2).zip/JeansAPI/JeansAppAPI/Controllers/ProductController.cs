﻿using JeansAppAPI.CustomerRepository;
using JeansAppAPI.Entities;
using JeansAppAPI.UserRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Drawing;

namespace JeansAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductAsyncRepository repository;
        public ProductController(IProductAsyncRepository repository)
        {
            this.repository = repository;
        }


        [HttpGet,Route("GetAllProducts")]
        [AllowAnonymous]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var product = await repository.GetAllProducts();
                return StatusCode(200, product);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet, Route("GetProducts/{productId}")]
        [Authorize(Roles ="Admin")]
        [AllowAnonymous]
        public async Task<IActionResult> GetAll(string productId)
        {
            var products = await repository.GetById(productId);
            return StatusCode(200, products);
        }
        [HttpPost,Route("AddProduct")]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> AddProduct(Product product)
        {
            try
            {
                await repository.AddProduct(product);
                return Ok(product);
            }
            catch (Exception ex)
            {
                return StatusCode(500,ex.Message);
            }
        }
        [HttpDelete, Route("DeleteProduct/{id}")]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> DeleteProduct(string id)
        {
            try
            {
                await repository.DeleteProduct(id);
                return NoContent();
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message); 
            }
        }
        [HttpPut, Route("UpdateProduct/{id}")]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> UpdateProduct(Product product)
        {
            try
            {
                await repository.UpdateProduct(product);
                return Ok();
            }
            catch ( Exception ex)
            {
                return StatusCode(500, ex.Message);                
            }
        }


        [HttpGet,Route("GetByCategory")]
        [AllowAnonymous]
        public async Task<IActionResult> GetByCategory(string? age, string? cloth, string? gender, int? size, string? color, string? brand)
        {
            try
            {
                var products = await repository.GetProductByCategory(age, cloth, gender,size,color,brand);
                return Ok(products);
            }
            catch (Exception ex)
            {
                return StatusCode(500,ex.Message);
            }
        }
    }
}
