﻿using JeansAppAPI.CustomerRepositories;
using JeansAppAPI.DTO;
using JeansAppAPI.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace JeansAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly ICartAsyncRepository _cartAsyncRepository;

        public CartController(ICartAsyncRepository cartAsyncRepository)
        {
            _cartAsyncRepository = cartAsyncRepository;
        }

        [HttpPost("AddCart")]
      //  [Authorize(Roles = "Customer")]

        public async Task<IActionResult> Add(CartDTO cartDTO)
        {
            var cart = new Cart
            {
                CartId = Guid.NewGuid(),
                ProductId = cartDTO.ProductId,
                CustomerId = cartDTO.CustomerId,
                Quaintity = cartDTO.Quantity,
            };
            try
            {
                var result = await _cartAsyncRepository.Add(cart);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpDelete("DeleteCart")]
        [Authorize(Roles = "Customer")]

        public async Task<IActionResult> Delete(Guid cartId)
        {
            try
            {
                await _cartAsyncRepository.DeleteCart(cartId);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet("GetCart")]
      //  [Authorize(Roles = "Customer")]

        public async Task<IActionResult> Get(string customerId)
        {
            try
            {
                var carts = await _cartAsyncRepository.GetCartList(customerId);
                return Ok(carts);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
            
        }
    }
}
