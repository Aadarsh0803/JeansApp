﻿using JeansAppAPI.Entities;
using JeansAppAPI.Models;
using JeansAppAPI.UserRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace JeansAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerRepository customerRepository;
        private IConfiguration _configuration;
        public CustomerController(ICustomerRepository customerRepository, IConfiguration configuration)
        {
            this.customerRepository = customerRepository;
            _configuration = configuration;
        }



        [HttpGet, Route("GetCustomers")]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> GetAll()
        {
            var customers = await customerRepository.GetAll();
            return StatusCode(200, customers);
        }
        [HttpGet, Route("GetCustomerByEmail/{email}")]
        [Authorize(Roles = "Admin,Customer")]

        public async Task<IActionResult> GetCustomerByEmail(string email)
        {
            try
            {
                var customer = await customerRepository.GetByEmail(email);
                return Ok(customer); // Return 200 status code with customer data
            }
            catch (ArgumentException)
            {
                return NotFound("Customer not found"); // Return 404 status code if customer not found
            }
            catch (Exception ex)
            {
                // Log exception details here if necessary
                return StatusCode(500, $"Internal server error: {ex.Message}"); // Return 500 status code for unexpected errors
            }
        }


        [HttpDelete, Route("Delete/{email}")]
        [Authorize(Roles = "Admin,Customer")]
        public async Task<IActionResult> Delete(string email)
        {
            var customer = await customerRepository.FindByEmail(email);
            if (customer == null)
            {
                return NotFound(new { message = "Customer not found." });
            }
            await customerRepository.Delete(email);
            return NoContent();
        }

        [HttpPost, Route("Add")]
        [AllowAnonymous]
        public async Task<IActionResult> Add(Customer customer)
        {
            try
            {
                await customerRepository.Add(customer);
                return StatusCode(200, customer);
            }
            catch (DbUpdateException ex)
            {
                var sqlException = ex.InnerException as SqlException;
                if (sqlException != null)
                {
                    if (sqlException.Number == 2627 || sqlException.Number == 2601) 
                    {
                        if (sqlException.Message.Contains("Email"))
                        {
                            return Conflict(new { message = "The email address is already in use." });
                        }
                        if (sqlException.Message.Contains("UserName"))
                        {
                            return Conflict(new { message = "The username is already in use." });
                        }
                    }
                }
                return StatusCode(500, new { message = "An error occurred while processing your request." });
            }
        }
        [HttpPut,Route("Update/{email}")]
        [Authorize(Roles = "Admin,Customer")]
        public async Task<IActionResult> Update(Customer customer)
        {
            try
            {
                await customerRepository.Update(customer);
                return StatusCode(200, customer);
            }
            catch(Exception ex) 
            {
                    return StatusCode(500, ex.Message);
            }
            
        }
        [HttpPost, Route("Validate")]
        [AllowAnonymous]
        public async Task<IActionResult> Get(Login login)
        {
            try
            {
                var user = await customerRepository.ValidUser(login.UserName, login.Email, login.Password);
                if (user != null)
                {
                    var authResponse = new AuthResponse()
                    {
                        CustomerId = user.CustomerId,
                        Role = user.Role,
                        UserName = user.UserName,
                        FirstName = user.FirstName,
                        LastName = user.LastName,
                        Email = user.Email,
                        PhoneNumber = user.PhoneNumber,
                        Address = user.Address,
                        City = user.City,
                        PostalCode = user.PostalCode,
                        State = user.State,
                        Country = user.Country,
                        Token = GetToken(user)
                    };
                    return Ok(authResponse);
                }

                return NotFound("User not found or invalid credentials.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        private string GetToken(Customer customer)
        {
            var issuer = _configuration["Jwt:Issuer"];
            var audience = _configuration["Jwt:Audience"];
            var key = Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]);
            //Header section
            var signingCredentials = new SigningCredentials(
                new SymmetricSecurityKey(key),
                SecurityAlgorithms.HmacSha512Signature
            );
            //Payload section
            var subject = new ClaimsIdentity(new[]
            {
               // new Claim(ClaimTypes.NameIdentifier, issuer),
                        new Claim(ClaimTypes.Email,customer.Email),
                        new Claim(ClaimTypes.Role, customer.Role),
                    });

            var expires = DateTime.UtcNow.AddMinutes(10);//token will expire after 10min

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = subject,
                Expires = expires,
                Issuer = issuer,
                Audience = audience,
                SigningCredentials = signingCredentials
            };
            //generate token using tokenDescription
            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var jwtToken = tokenHandler.WriteToken(token);
            return jwtToken;
        }

    }
}
