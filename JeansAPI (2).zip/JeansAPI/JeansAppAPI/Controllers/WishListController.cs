﻿using JeansAppAPI.CustomerRepositories;
using JeansAppAPI.DTO;
using JeansAppAPI.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace JeansAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WishListController : ControllerBase
    {
        private readonly IWishListAsyncRepository wishListAsyncRepository;
        private readonly IConfiguration _configuration;

        public WishListController(IWishListAsyncRepository wishListAsyncRepository, IConfiguration configuration)
        {
            this.wishListAsyncRepository = wishListAsyncRepository;
            _configuration = configuration;
        }

        [HttpGet("{customerId}")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> Get(string customerId)
        {
            if (string.IsNullOrEmpty(customerId))
            {
                return BadRequest("Customer ID is required.");
            }

            try
            {
                var wish = await wishListAsyncRepository.GetWishList(customerId);
                if (wish == null)
                {
                    return NotFound($"Wishlist for customer ID {customerId} not found.");
                }

                return Ok(wish);
            }
            catch (Exception ex)
            {
                // Consider using a logging framework
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Authorize(Roles = "Customer")]

        public async Task<IActionResult> Add([FromBody] WishDTO wishDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var wish = new WishList()
                {
                    // WishListId = Guid.NewGuid(), // ID generation should be handled by the database or ORM
                    productId = wishDTO.ProductId,
                    customerId = wishDTO.customerId
                };

                var result = await wishListAsyncRepository.AddWishList(wish);
                return CreatedAtAction(nameof(Get), new { customerId = wish.customerId }, result);
            }
            catch (Exception ex)
            {
                // Consider using a logging framework
                return StatusCode(500, ex.Message);
            }
        }

        [HttpDelete,Route("deleteWish/{wishId}")]
        [Authorize(Roles = "Customer")]

        public async Task<IActionResult> Delete(Guid wishId)
        {

            await wishListAsyncRepository.DeleteWishList(wishId);
            return NoContent();
            
        }
    }
}
