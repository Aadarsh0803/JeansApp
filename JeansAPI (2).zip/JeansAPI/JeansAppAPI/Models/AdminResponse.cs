﻿using System.Globalization;

namespace JeansAppAPI.Models
{
    public class AdminResponse
    {
        public string AdminId { get; set; }
        public string AdminName { get; set; }
        public string email { get; set; }
        public string Token {  get; set; }

    }
}
