﻿
using System.ComponentModel.DataAnnotations;

namespace JeansAppAPI.DTO
{
    public class OrderDTO
    {
        [Key]
        public string OrderId { get; set; }
        public DateTime OrderDate { get; set; }
        public string CustomerId { get; set; }
        public string orderStatus { get; set; }
    }

    public class WishDTO
    {
        [Key]
        public string WishId { get; set; }
        public string ProductId { get; set; }
        public string customerId { get; set; }
    }

    public class CartDTO
    {
        [Key]
        public Guid CartListId { get; set; }
        public string CustomerId { get; set; }
        public string ProductId { get; set; }
        public int Quantity { get; set; }
    }

    public class ReviewDTO
    {
        [Key]
        public string ReviewId { get; set; }
        public string ProductId { get; set; }
        public string CustomerId { get; set; }
        public int Ratings { get; set; }
        public string Description { get; set; }
    }
    public class TransactionDTO
    {
        [Key]
        public Guid TransactionId { get; set; }
        public string CustomerId { get; set; }
        public string OrderId { get; set; }
        public decimal Amount { get; set; }
        public string TransactionMethod { get; set; }
        public DateTime TransactionDate { get; set; }
    }
    public class OrderItemDTO
    {
        public string ItemId { get; set; }
        public string OrderId { get; set; }
        public string ProductId { get; set; }
        public decimal Price { get; set; }
        public decimal Discount { get; set; }
        public int Quantity { get; set; }
    }
}
