using JeansAppAPI.CustomerRepositories;
using JeansAppAPI.CustomerRepository;
using JeansAppAPI.Entities;
using JeansAppAPI.UserRepository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;

namespace JeansAppAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddDbContext<JeansContext>();
            builder.Services.AddTransient<ICustomerRepository, Customerrepository>();
            builder.Services.AddTransient<IProductAsyncRepository, ProductAsyncRepository>();
            builder.Services.AddTransient<IOrderAsyncRepository, OrderAsyncRepository>();
            builder.Services.AddTransient<IWishListAsyncRepository, WishListAsyncRepository>();
            builder.Services.AddTransient<ICartAsyncRepository, CartAsyncRepository>();
            builder.Services.AddTransient<IReviewAsyncRepository, ReviewAsyncRepository>();
            builder.Services.AddTransient<ITransactionAsyncRepository, TransactionAsyncRepository>();
            builder.Services.AddTransient<IOrderItemAsyncRepository, OrderItemAsyncRepository>();

            builder.Services.AddControllers();

            //configure CORS
            builder.Services.AddCors(c=>
            {
                c.AddPolicy("AllowOrigin", options =>
                options.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
            });

            /*            builder.Services.AddCors(options =>
                        {                                       JASHWANTH
                            options.AddDefaultPolicy(
                                builder =>
                                {
                                    builder.WithOrigins("http://localhost:3000").AllowAnyMethod().AllowAnyHeader();
                                });
                        });*/

            // builder.Services.AddControllers();
            builder.Services.AddControllers(options =>
            options.Filters.Add(new GlobalExceptionFilter()));
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();



            #region TokenValidationCode
            builder.Services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(o =>
            {
                o.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidIssuer = builder.Configuration["Jwt:Issuer"],
                    ValidAudience = builder.Configuration["Jwt:Audience"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"])),
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = false,
                    ValidateIssuerSigningKey = true
                };
            });
            #endregion
            //Configure Swagger UI to validate token
            #region Swagger UI for Validate Token
            builder.Services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Jeans_API",
                    Version = "v1"
                });
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 1safsfsdfdfd\"",
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement {
        {
            new OpenApiSecurityScheme {
                Reference = new OpenApiReference {
                    Type = ReferenceType.SecurityScheme,
                        Id = "Bearer"
                }
            },
            new string[] {}
        }
    });
            });
            #endregion




            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();

                app.UseDeveloperExceptionPage(); //Gives error details
               // app.UseExceptionHandler("/Error");
            }

            //add cors to middleware
            app.UseCors("AllowOrigin");
            app.UseAuthentication();
            app.UseAuthorization();

           
            app.MapControllers();

            app.Run();
        }
    }
}
