﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JeansAppAPI.Entities
{
    public class Cart
    {
        [Key]
        public Guid CartId { get; set; }
        public int Quaintity {  get; set; }

        [ForeignKey("Product")]
        public string ProductId { get; set; }

        [ForeignKey("Customer")]
        public string CustomerId { get; set; }

        public Product Product { get; set; }
        public Customer Customer { get; set; }
    }
}

