﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JeansAppAPI.Entities
{
    public class Order
    {
        [Key]

        public string OrderId { get; set; }

        [ForeignKey("Customer")]
        public string CustomerId { get; set; }


        public DateTime DateOfDelivery { get; set; }

        [Required]
        [StringLength(20)]
        public string OrderStatus { get; set; }

        public virtual Customer Customer { get; set; }

        public virtual ICollection<OrderItem> OrderItems { get; set; }
    }
}
