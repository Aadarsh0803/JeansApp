﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JeansAppAPI.Entities
{
    public class WishList
    {
        [Key]
        public Guid WishListId { get; set; }
        [ForeignKey("Product")]
        public string productId {  get; set; }
        [ForeignKey("Customer")]
     
        public string customerId { get; set; }
        public Product product { get; set; }
        public Customer customer { get; set; }
    }
}
