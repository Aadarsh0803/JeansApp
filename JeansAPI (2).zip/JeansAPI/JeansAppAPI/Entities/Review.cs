﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JeansAppAPI.Entities
{
    public class Review
    {
        [Key]
        public Guid ReviewId { get; set; }
        [Range(1,5)]
        public int Ratings { get; set; }
        [StringLength(200)]
        public string Description { get; set; }

        [ForeignKey("Product")]
        public string ProductId { get; set; }
        public Product Product { get; set; }
        [ForeignKey("Customer")]
        public string CustomerId { get; set; }
        public Customer Customer { get; set; }
    }
}
