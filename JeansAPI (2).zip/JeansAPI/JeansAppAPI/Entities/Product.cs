﻿using System.ComponentModel.DataAnnotations;

namespace JeansAppAPI.Entities
{
    public class Product
    {

        [Key]
        [Required]
        public string ProductId {  get; set; }
        [Required]
        [StringLength(20)]
        public string ProductName { get; set; }
        [StringLength(100)]
        public string ProductDescription { get; set; }
        public string Gender { get; set; }
        public string Cloth {  get; set; }
        public string Age { get; set; }
        [Required]
        public decimal Price { get; set; }        
        public decimal Discount { get; set; }
        [Required]
        public int Size { get; set; }
        public int Quantity { get; set; }
        public string Color { get; set; }
        [Required]
        [StringLength (20)]
        public string Brand { get; set; }
    }
}
