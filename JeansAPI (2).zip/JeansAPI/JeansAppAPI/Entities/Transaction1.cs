﻿using System.ComponentModel.DataAnnotations;

namespace JeansAppAPI.Entities
{
    public class Transaction1
    {
        [Key]
        public Guid TransactionId { get; set; }
        public string OrderId { get; set; }
        public string CustomerId { get; set; }
        public decimal Amount { get; set; }
        public string TransactionMethod { get; set; }
        public DateTime TransactionDate { get; set; }

    }
}
